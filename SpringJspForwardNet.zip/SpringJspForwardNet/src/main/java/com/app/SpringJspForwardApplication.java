package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJspForwardApplication {

	public static void main(String[] args) {
		System.out.println("hello");
		SpringApplication.run(SpringJspForwardApplication.class, args);
	}

}
